import subprocess
import sys
subprocess.Popen([sys.executable, "reg.py"])
