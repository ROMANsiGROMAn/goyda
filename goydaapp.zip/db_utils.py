import os
import sys
import hashlib
import random
import dropbox
import sqlite3

# Конфигурация
DROPBOX_TOKEN = "sl.u.AFjZcnzHHugXwhKQxhjSmNX_6mKTqFtj4vK7-xOPLIY8K1AMjPOaSzfQN_txE4EW7WuJa0nZblsou3WBi5TPkx59JTUCHezT16ga0ldU7GELkkdF1-r1Dc0hDuJqEPhgOYtJazSpMkcAL7DIAujqBGJPjL-O9dFBEg9lVLsgQ5piqbJAEqHx8dRH7QzxsnxitSD39efZGNeUdOm9KhJ1LZYdnmAxYf7yjW6XQBOGxGf60lCO1BAjF1OlaQw1dEzfrVaLfsJClVfh0SP-y6x_WIeqk7NyZMSzKNCgGZI_tNDL4rsu7Nm6Tx8Vm6zqHKcQwYzchSepZQwrBOfzqyT7QIcfkmypkfBoxv59T4VJ7HbjgMLfZ3kWahc2_KwVwrujWu2AN2lP1sbab7nisKL2WtlxNlmWRD7rdTTElt4D0XR2IdoPOmnmD5lf4n0p95LN5Pgkxh_ODCLEx2UozaBX2DYBuFoNgrCGZs7MXGNWKANgcLkttWUq1ewjawhGkk2fPX8rpdngPb0A9_LnlRhHlnMJ7a2iSWafDWzfpd4h6KroOrTtbUw15dE3bseDI-FwsQq41I_KlhWgD_nlpwHsdeSfUi3wyneckC7Ixfzw42yUNiGjZ-yVdobD61JyDJgC7vji6OtO4pThOmmGC_iiISYtDJs_A3dSP0Fc8a_kytdSz9R-Nyp-mMbsOhq_vYaxqECuE6mC8VFr0DEYubAHhtih3kOAAr7LMLnLXByq-J51qC7MKtaEaQXWVtFdgHkP37O3n9ZXStNeW1jaTV2qtVu1IX6eCaylzO05cOTBnHuxjTDxj7_iaUh55oxW-i2uLoMZewrb9tLrcmp7ZYEI-LWMdxWXifO4b0BCg25u1-voHCw4phovY_gF9Y9YlWtSVF9Fq37qXDmOJChhmWCsbpf4iSsXQ59VNPp_MoieWa5YDfPwqEqUrBJOyGfZRdfs1ftl3ihdr5Gk_uuz3lV8H9ktFE5r1_tBPMzn533w8rh_x2yyqMuIiLqCbftMEviyXAtM-J-XAISqSGh_walOZND0V-ArbT9fXkaJbAQkgrBXDrK6GXQXDB7pD169ID3RvPFi-pINy8ZClf7VirZ_emzcfzvc32a7r6junuTZM69YDjHp8awvKoxybhCe4W8GmtL_pGbveJpnXVxJ_2kbxq5-eDJ4aozuaRc1YBFJRIX8vHQO6MbisuVAB4sAMKZHQeSjEXW346nVx57mpz6cWeO2FOy8fcp_mMQaaREFtqAa1lOAlcHNFmyqrNuwjsJ91tiTYprdSMM2CU6scjN6K54znNMBci0gHoC34vH6Bzb4CVE2Ov0TdIZqMq87bLHmwSty9AgO1Lx2Lu3UnKA8eF8AJ7yxR8RcBrZXHScw_Cm1yExSMtjGhhq4QI24P_uFoGmwJQwRUBugf1tGcx6fEwqrWer1Rod9fIAYbXc2IkSDMA"
DROPBOX_PATH = "/users.db"  # Путь к файлу на Dropbox

def generate_random_string(length=32):
    """Генерирует случайную строку заданной длины."""
    characters = "abcdefghijklmnopqrstuvwxwyz00112233445566778899"
    return ''.join(random.choice(characters) for _ in range(length))

def get_database_path():
    """Возвращает запутанный путь к базе данных в AppData/Local."""
    appdata_path = os.path.join(os.getenv('LOCALAPPDATA'), "f43613b5f4921fd80f18ff2395a43a8ec2529d2ad7172c4fdb5a1beb82ddf472") #Папка разработчика

    # Создаем основную папку разработчика, если её нет.
    if not os.path.exists(appdata_path):
        os.makedirs(appdata_path)

    # Генерация цепочки случайных папок:
    path_level_1 = os.path.join(appdata_path, generate_random_string())
    path_level_2 = os.path.join(path_level_1, generate_random_string())
    path_level_3 = os.path.join(path_level_2, generate_random_string())
    path_level_4 = os.path.join(path_level_3, generate_random_string()) #Дополнительный уровень
    #Проверка и создание папок
    for path in [path_level_1,path_level_2,path_level_3, path_level_4]:
         if not os.path.exists(path):
             os.makedirs(path)

    return os.path.join(path_level_4, "users.db")
DATABASE_FILE = get_database_path()

def resource_path(relative_path):
    """ Получает абсолютный путь к ресурсу, работающий как в обычном режиме, так и в frozen app. """
    try:
        # PyInstaller создает папку _MEIPASS временную папку и размещает там файлы
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")

    # Проверяем, не является ли relative_path именем файла базы данных
    if relative_path == "users.db":
        return get_database_path()  # Возвращаем запутанный путь к базе данных
    else:
        return os.path.join(base_path, relative_path)

def download_database():
    """Скачивает базу данных с Dropbox."""
    try:
        get_database_path() #Создаем структуру каталогов
        dbx = dropbox.Dropbox(DROPBOX_TOKEN)
        with open(DATABASE_FILE, "wb") as f:
            md, res = dbx.files_download(path=DROPBOX_PATH)
            f.write(res.content)
        print("База данных успешно загружена с Dropbox.")
        return True
    except Exception as e:
        print(f"Ошибка при загрузке базы данных: {e}")
        return False

def upload_database():
    """Загружает базу данных на Dropbox."""
    try:
        dbx = dropbox.Dropbox(DROPBOX_TOKEN)
        with open(DATABASE_FILE, "rb") as f:
            dbx.files_upload(f.read(), DROPBOX_PATH, mode=dropbox.files.WriteMode.overwrite)
        print("База данных успешно загружена на Dropbox.")
        return True
    except Exception as e:
        print(f"Ошибка при загрузке базы данных: {e}")
        return False
def get_users():
    """Получает список пользователей из базы данных."""
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, email FROM users")  # Извлекаем только нужные поля
        users = cursor.fetchall()
        conn.close()
        return users
    except sqlite3.Error as e:
        print(f"Ошибка при работе с базой данных: {e}")
        return None

def add_user(username, email, password):
    """Добавляет нового пользователя в базу данных и загружает ее на Dropbox."""
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, password))
        conn.commit()
        print(f"Пользователь {username} успешно добавлен локально.")
        conn.close()

        # После добавления пользователя, загружаем базу данных на Dropbox
        if upload_database():
            print("База данных успешно обновлена на Dropbox.")
        else:
            print("Ошибка при обновлении базы данных на Dropbox.")

    except sqlite3.Error as e:
        print(f"Ошибка при работе с базой данных: {e}")
    finally:
        if conn and hasattr(conn, 'close') and callable(getattr(conn, 'close')): #Проверяем, что коннект был создан, что у него есть метод close и что это метод
            conn.close()
download_database()