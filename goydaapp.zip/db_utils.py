import os
import sys
import hashlib
import random
import dropbox
import sqlite3

# Конфигурация
DROPBOX_TOKEN = "sl.u.AFjcEwJcjPZiEY7gf6r5lZSgG90hGii-kWoNPForKHyyLzcQmBUTgeTrVEF_EYQa0G-_MbeoJmPIy4WtVodhjr0cn4A0Cs_ZYGRCLT_SD8_1yfeQ78DO_29VFez70hmQspdR4h2XisYkpb5kpzSwtstDW7-RAnQAT0l8deW_nfG5PmQcGOLLRhchCHkWy8wcmrk8A2vrp0xzZfVaoGRdx7aFb6aKHbtnDszEPggNtcss5-lcV-8_1TyZ7-NEyD3y-TgAr4S4PsBP_QgXH312SjKsCRVWIvA4UiEzhpk4brMIU4MBDE0eWIITJnAVOe_jLWnrOnZubYqpDnDwMJwFXX81y3V6A0Fo0qsGCkO_eoMnPNaxMY70_0bQmzQ22oU5MTKjIpuTIwMIEN97x_p8OOs0eJHHi0NW0HyE3cGqJluBI4_cA9g8eoDgcVjPK0MgbnptTxzTaNUwdoTW-Xj8qteUWGebtExObvo0168fHkvDvb_DDA5hukQ9ZhUEKOmC-0qzfcYq25lKBR88P60Jmz96ZjHQ4Rkbu7iKQ2EOytQL4vSAKCrkwydybySo06PTBmHLZj9bvoi5KEJ4e34MQtLe-E_NBFp5YrH8OD5r_Ub9hhWfbS04IA59uaaQ4bCZde9xrNLnu9YE2eQPMWxhcxOhULnJJJAYVIaBAfTS0viTw2QwcMZ2LBOhFCFXuNpzSGe9YFd0zr8YNHGSYdmAbic4qJbvyx_QbWSRpNbkIMdYC9hHh75uCj0gVgXABaR5SKbqEelroF4xkeG4hARH9CD6ctFGCiIcQFbP5Mt3bm_N1NQwCCkPtY8ebrPUyQOOz81i-cog1FZwPxzZFYi8a-eBdMQ5l03IFdPhyQp9Nhz7YBauPe97t8L9QZiQeUerwNK1HBlDm5Y_2ufM9UcRMI8zHsPSF1OBuP4QPEpdQBQ7DoscNK0CsG3oVx6BEPwN_hEnhL8vdIgJLoxJsOP_Lh39vztuR2OR2rXybtQ9ZOzCEcYyDizEKcnSMOnYuqyYqYkqyt15mBM3q73vxuL6WgcgGDwkxna10G0VwhV0UalMoOw9AjIuH3UKODGL2IZLGg8sugDmm3YH70MvgPofcpFwzV8-xi4bHGl2HF0ir0F-u3JJ3DA7so6ogaefFl-PjlhES75jcUnc6Xi4i9MyTNU0NjIj4e9KmMLwrIOTMGQ9Y3Lzr7_FAWDGMXRm8jWB67w8kBq5nFFDAXuRxbz4p0hJ0K1JxTv-FMgkRtLKJ_zBNMpqsix3egPPd55UxfCVHp2LC2Bp213WQTD0UDmoS3sYhxFAfPOxHY4qTdRHGUGtiWZRLqZF4d6NqSlIEzdqYJvCpkLZkrc4LKRFsvRznkFQkFbgQw9pT6F9Rv8DatTWXI83g7BILwQ4L0W4GEVpc8QvyY6aSRD5sF3-12OTfZqfY907EWy5OSA6YM5pCRc3fA"
DROPBOX_PATH = "/users.db"  # Путь к файлу на Dropbox

def generate_random_string(length=32):
    """Генерирует случайную строку заданной длины."""
    characters = "abcdefghijklmnopqrstuvwxwyz00112233445566778899"
    return ''.join(random.choice(characters) for _ in range(length))

def get_database_path():
    """Возвращает запутанный путь к базе данных в AppData/Local."""
    appdata_path = os.path.join(os.getenv('LOCALAPPDATA'), "f43613b5f4921fd80f18ff2395a43a8ec2529d2ad7172c4fdb5a1beb82ddf472") #Папка разработчика

    # Создаем основную папку разработчика, если её нет.
    if not os.path.exists(appdata_path):
        os.makedirs(appdata_path)

    # Генерация цепочки случайных папок:
    path_level_1 = os.path.join(appdata_path, generate_random_string())
    path_level_2 = os.path.join(path_level_1, generate_random_string())
    path_level_3 = os.path.join(path_level_2, generate_random_string())
    path_level_4 = os.path.join(path_level_3, generate_random_string()) #Дополнительный уровень
    #Проверка и создание папок
    for path in [path_level_1,path_level_2,path_level_3, path_level_4]:
         if not os.path.exists(path):
             os.makedirs(path)

    return os.path.join(path_level_4, "users.db")
DATABASE_FILE = get_database_path()

def resource_path(relative_path):
    """ Получает абсолютный путь к ресурсу, работающий как в обычном режиме, так и в frozen app. """
    try:
        # PyInstaller создает папку _MEIPASS временную папку и размещает там файлы
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")

    # Проверяем, не является ли relative_path именем файла базы данных
    if relative_path == "users.db":
        return get_database_path()  # Возвращаем запутанный путь к базе данных
    else:
        return os.path.join(base_path, relative_path)

def download_database():
    """Скачивает базу данных с Dropbox."""
    try:
        get_database_path() #Создаем структуру каталогов
        dbx = dropbox.Dropbox(DROPBOX_TOKEN)
        with open(DATABASE_FILE, "wb") as f:
            md, res = dbx.files_download(path=DROPBOX_PATH)
            f.write(res.content)
        print("База данных успешно загружена с Dropbox.")
        return True
    except Exception as e:
        print(f"Ошибка при загрузке базы данных: {e}")
        return False

def upload_database():
    """Загружает базу данных на Dropbox."""
    try:
        dbx = dropbox.Dropbox(DROPBOX_TOKEN)
        with open(DATABASE_FILE, "rb") as f:
            dbx.files_upload(f.read(), DROPBOX_PATH, mode=dropbox.files.WriteMode.overwrite)
        print("База данных успешно загружена на Dropbox.")
        return True
    except Exception as e:
        print(f"Ошибка при загрузке базы данных: {e}")
        return False
def get_users():
    """Получает список пользователей из базы данных."""
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, email FROM users")  # Извлекаем только нужные поля
        users = cursor.fetchall()
        conn.close()
        return users
    except sqlite3.Error as e:
        print(f"Ошибка при работе с базой данных: {e}")
        return None

def add_user(username, email, password):
    """Добавляет нового пользователя в базу данных и загружает ее на Dropbox."""
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, password))
        conn.commit()
        print(f"Пользователь {username} успешно добавлен локально.")
        conn.close()

        # После добавления пользователя, загружаем базу данных на Dropbox
        if upload_database():
            print("База данных успешно обновлена на Dropbox.")
        else:
            print("Ошибка при обновлении базы данных на Dropbox.")

    except sqlite3.Error as e:
        print(f"Ошибка при работе с базой данных: {e}")
    finally:
        if conn and hasattr(conn, 'close') and callable(getattr(conn, 'close')): #Проверяем, что коннект был создан, что у него есть метод close и что это метод
            conn.close()
download_database()