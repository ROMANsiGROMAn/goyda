# app.py (LoginForm)
import sys
import os
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QLineEdit,
                             QPushButton, QVBoxLayout, QStyle, QDesktopWidget, QMessageBox,
                             QHBoxLayout, QSizePolicy)  # Added QHBoxLayout and QSizePolicy
from PyQt5.QtCore import Qt, QSize  # Added QSize
from PyQt5.QtGui import QFont, QPalette, QColor
import sqlite3
import hashlib
import subprocess
import db_utils  # Import db_utils


class LoginForm(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Вход")
        self.setGeometry(0, 0, 500, 400)  # Increased window width and height
        self.center()  # Center the window

        # Database setup
        self.conn = None
        try:
            if not db_utils.download_database():
                QMessageBox.critical(self, "Ошибка", "Не удалось скачать базу данных!")
                sys.exit()

            self.conn = sqlite3.connect(db_utils.DATABASE_FILE)
            self.cursor = self.conn.cursor()
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка подключения к базе данных: {e}")
            sys.exit()

        # UI elements
        self.email_label = QLabel("Электронная почта:")
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("Почта")
        self.email_input.setMaxLength(50)

        self.password_label = QLabel("Пароль:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)  # Password masking
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setMaxLength(50)

        self.login_button = QPushButton("Войти")
        self.login_button.clicked.connect(self.handle_login)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #ef4444;")
        self.error_label.setAlignment(Qt.AlignCenter)

        self.register_label = QLabel(
            '<a href="#" style="text-decoration:none; color:#818cf8;">Нет аккаунта? Зарегистрироваться!</a>')
        self.register_label.setOpenExternalLinks(False)
        self.register_label.setAlignment(Qt.AlignCenter)
        self.register_label.linkActivated.connect(self.open_registration)

        self.privacy_policy_label = QLabel(
            '<a href="https://docs.google.com/document/d/1NnVudOoUynTxaAliyx1aVsDRVoMq7iFqmUESt_suWBw/edit?usp=sharing" style="text-decoration:none; color:#818cf8;">Политика конфиденциальности</a>')
        self.privacy_policy_label.setOpenExternalLinks(True)  # Открывать ссылку в браузере
        self.privacy_policy_label.setAlignment(Qt.AlignCenter)

        # Central Widget
        central_widget = QWidget()
        central_layout = QVBoxLayout(central_widget)
        central_layout.addWidget(self.email_label)
        central_layout.addWidget(self.email_input)
        central_layout.addWidget(self.password_label)
        central_layout.addWidget(self.password_input)
        central_layout.addWidget(self.login_button)
        central_layout.addWidget(self.error_label)
        central_layout.addWidget(self.register_label)
        central_layout.addWidget(self.privacy_policy_label)

        # Set fixed size for the central widget
        central_widget.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        central_widget.setFixedWidth(500)  # Set fixed width for the central widget

        # Main layout
        main_layout = QHBoxLayout(self)
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(central_widget)

        # CSS-like styling - Adjusted for better sizing
        self.setStyleSheet("""
            QWidget {
                font-family: 'Inter', sans-serif;
                background: rgba(30, 41, 59, 0.8);
                color: #f1f5f9;
                border-radius: 24px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
                            0 2px 4px -1px rgba(0, 0, 0, 0.06),
                            0 0 0 1px rgba(255, 255, 255, 0.1);
                padding: 0px;
            }
            
            /* Style for the central widget */
            QWidget {
                background: rgba(30, 41, 59, 0.8);
                padding: 32px;
            }

            QLabel {
                margin-bottom: 6px;
                font-size: 14px;
                font-weight: 500;
            }

            QLineEdit {
                padding: 8px 12px;
                background: rgba(255, 255, 255, 0.05);
                border: 2px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                font-size: 14px;
                color: #f1f5f9;
                box-sizing: border-box;
                margin-bottom: 12px;
            }

            QLineEdit:focus {
                outline: none;
                border-color: #4f46e5;
                box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
            }

            QPushButton {
                padding: 10px;
                background: #4f46e5;
                border: none;
                border-radius: 8px;
                color: white;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                margin-top: 24px;
            }

            QPushButton:hover {
                background: #818cf8;
                box-shadow: 0 4px 12px rgba(79, 70, 229, 0.4);
            }

            QLabel[style*="color: red;"] {
                margin-top: 6px;
                text-align: center;
                font-size: 12px;
            }
        """)

        # Set fonts
        font = QFont('Inter', 12)
        self.setFont(font)

        # Custom Palette for Links
        palette = QPalette()
        palette.setColor(QPalette.Link, QColor(0x81, 0x8c, 0xf8))
        self.register_label.setPalette(palette)
        self.privacy_policy_label.setPalette(palette)

    def center(self):
        """Centers the window on the screen."""
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def handle_login(self):
        """Handles the login process."""
        email = self.email_input.text()
        password = self.password_input.text()

        if not email or not password:
            self.error_label.setText("Пожалуйста, заполните все поля.")
            return

        # Hash the password
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        try:
            # Check if the user exists in the database
            self.cursor.execute("SELECT * FROM users WHERE email = ? AND password = ?",
                                (email, hashed_password))
            user = self.cursor.fetchone()

            if user:
                self.error_label.setText("")
                QMessageBox.information(self, "Успех", "Вы успешно вошли в систему!")
                username = user[1]  # Get username from the database (second column)
                self.open_chat(username)  # Start chat.py with the username
            else:
                self.error_label.setText("Неверная электронная почта или пароль.")

        except sqlite3.Error as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка входа: {e}")

    def open_registration(self):
        """Placeholder function to open the registration form."""
        try:
            reg_script_path = os.path.abspath("reg.py")
            subprocess.Popen([sys.executable, reg_script_path])
        except FileNotFoundError:
            QMessageBox.critical(self, "Ошибка", "Файл reg.py не найден.")

    def open_chat(self, username):
        """Opens the chat.py application with the given username."""
        try:
            self.close()
            subprocess.Popen([sys.executable, "chat.py", username])  # Start chat.py
        except FileNotFoundError:
            QMessageBox.critical(self, "Ошибка", "Файл chat.py не найден.")

    def closeEvent(self, event):
        """Handles the closing of the application."""
        if self.conn:
            self.conn.close()
        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)

    # Set global style
    app.setStyleSheet("""
        body {
            background: linear-gradient(135deg, #0f172a, #1e293b);
        }
    """)

    form = LoginForm()
    form.show()
    sys.exit(app.exec_())