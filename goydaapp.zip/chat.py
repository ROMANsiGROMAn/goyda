import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                             QLineEdit, QPushButton, QLabel, QSpacerItem,
                             QSizePolicy, QTextEdit, QMessageBox, QListWidget)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont
import sqlite3
import datetime
import db_utils  # Import the db_utils module

python_executable = sys.executable

class GoidaZvonUI(QWidget):
    def __init__(self, username):
        super().__init__()

        self.username = username
        self.background_color = "#36393F"
        self.left_panel_color = "#2F3136"
        self.input_background_color = "#40444B"
        self.text_color = "#FFFFFF"
        self.accent_color = "#0ccfc2"

        self.default_font = QFont("Arial", 12)
        self.bold_font = QFont("Arial", 12, QFont.Bold)

        self.user_id = None
        self.friends = []
        self.chat_users = set()
        self.current_chat_user = None
        self.last_message_time = None  # Время последнего полученного сообщения
        self.poll_interval = 5000  # Интервал опроса (5 секунд)

        if not db_utils.download_database():
            QMessageBox.critical(self, "Ошибка", "Не удалось скачать базу данных. Приложение не может быть запущено.")
            sys.exit()
        self.load_data()

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.left_panel = QWidget()  # Добавлено определение self.left_panel
        self.left_panel.setStyleSheet(f"background-color: {self.left_panel_color};")
        self.left_panel.setFixedWidth(200)

        left_panel_layout = QVBoxLayout(self.left_panel)
        left_panel_layout.setContentsMargins(10, 10, 10, 10)
        left_panel_layout.setSpacing(10)

        goida_label = QLabel("GOIDAZVON")
        font = QFont("Berlin Sans FB Demi", 18)
        goida_label.setFont(font)
        goida_label.setStyleSheet(f"color: {self.accent_color};")
        left_panel_layout.addWidget(goida_label)

        self.user_list = QListWidget()
        self.user_list.setStyleSheet(f"""
            QListWidget {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                padding: 5px;
            }}
        """)
        self.user_list.setFont(self.default_font)
        self.user_list.itemClicked.connect(self.select_chat_user)
        left_panel_layout.addWidget(self.user_list)
        self.update_user_list()

        left_panel_layout.addItem(QSpacerItem(1, 1, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.settings_button = QPushButton("⚙️")
        self.settings_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.accent_color};
                color: {self.text_color};
                border: none;
                border-radius: 10px;
                padding: 5px 10px;
                font-size: 18px;
            }}
            QPushButton:hover {{
                background-color: #0aa99f;
            }}
        """)
        self.settings_button.setFont(self.default_font)
        self.settings_button.clicked.connect(self.toggle_theme)
        left_panel_layout.addWidget(self.settings_button)

        main_layout.addWidget(self.left_panel)  # Используем self.left_panel

        right_panel = QWidget()
        right_panel.setStyleSheet(f"background-color: {self.background_color};")

        right_panel_layout = QVBoxLayout(right_panel)
        right_panel_layout.setContentsMargins(10, 10, 10, 10)
        right_panel_layout.setSpacing(10)

        top_bar = QWidget()
        top_bar_layout = QHBoxLayout(top_bar)
        top_bar_layout.setContentsMargins(0, 0, 0, 0)
        top_bar_layout.setSpacing(10)

        back_button = QPushButton("<")
        back_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.input_background_color};
                color: {self.accent_color};
                border: none;
                border-radius: 10px;
                padding: 5px 10px;
            }}
            QPushButton:hover {{
                background-color: #50545B;
            }}
        """)
        back_button.setFont(self.default_font)
        top_bar_layout.addWidget(back_button)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Поиск пользователя...")
        self.search_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                border-radius: 10px;
                padding: 5px;
            }}
        """)
        self.search_input.setFont(self.default_font)
        top_bar_layout.addWidget(self.search_input)

        self.search_button = QPushButton("Найти")
        self.search_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.input_background_color};
                color: {self.accent_color};
                border: none;
                border-radius: 10px;
                padding: 5px 10px;
            }}
            QPushButton:hover {{
                background-color: #50545B;
            }}
        """)
        self.search_button.setFont(self.default_font)
        self.search_button.clicked.connect(self.search_user)
        top_bar_layout.addWidget(self.search_button)

        self.call_button = QPushButton("Звонок")
        self.call_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.input_background_color};
                color: {self.accent_color};
                border: none;
                border-radius: 10px;
                padding: 5px 10px;
            }}
            QPushButton:hover {{
                background-color: #50545B;
            }}
        """)
        self.call_button.setFont(self.default_font)
        self.call_button.clicked.connect(self.start_call)
        top_bar_layout.addWidget(self.call_button)
        top_bar_layout.setAlignment(self.call_button, Qt.AlignRight)

        self.username_label = QLabel(f"@{self.username}")
        self.username_label.setStyleSheet(f"""
            QLabel {{
                color: {self.accent_color};
                font-size: 14px;
            }}
        """)
        self.username_label.setFont(self.bold_font)
        self.username_label.setAlignment(Qt.AlignRight | Qt.AlignTop)
        top_bar_layout.addWidget(self.username_label)
        top_bar_layout.setAlignment(self.username_label, Qt.AlignRight)

        right_panel_layout.addWidget(top_bar)

        self.chat_area = QTextEdit()
        self.chat_area.setReadOnly(True)
        self.chat_area.setStyleSheet(f"""
            QTextEdit {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                padding: 5px;
            }}
        """)
        right_panel_layout.addWidget(self.chat_area)

        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Введите сообщение...")
        self.message_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                border-radius: 10px;
                padding: 5px;
            }}
        """)
        right_panel_layout.addWidget(self.message_input)

        self.send_button = QPushButton("Отправить")  #  Определяем self.send_button ЗДЕСЬ
        self.send_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.input_background_color};
                color: {self.accent_color};
                border: none;
                border-radius: 10px;
                padding: 5px 10px;
            }}
            QPushButton:hover {{
                background-color: #50545B;
            }}
        """)
        self.send_button.setFont(self.default_font)
        self.send_button.clicked.connect(self.send_message)
        right_panel_layout.addWidget(self.send_button)

        main_layout.addWidget(right_panel)

        self.setGeometry(100, 100, 800, 600)
        self.setWindowTitle("GoidaZvon")
        self.setStyleSheet(f"background-color: {self.background_color}; color: {self.text_color};")
        self.show()

        self.start_polling_timer() #Запускаем таймер

    def load_data(self):
        """Loads user-specific data from the database."""
        self.user_id = self.get_user_id_from_db()
        self.friends = self.load_friends_from_db()
        self.chat_users = set(self.friends)

    def get_user_id_from_db(self):
        """Gets the user ID from the database."""
        conn = None
        try:
            conn = sqlite3.connect(db_utils.DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (self.username,))
            user = cursor.fetchone()
            if user:
                return user[0]
            else:
                return None
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def load_friends_from_db(self):
        """Loads the list of friends from the database."""
        conn = None
        try:
            conn = sqlite3.connect(db_utils.DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute("SELECT users.username FROM friends INNER JOIN users ON friends.friend_id = users.id WHERE friends.user_id = ?", (self.user_id,))
            friends = [row[0] for row in cursor.fetchall()]
            return friends
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return []
        finally:
            if conn:
                conn.close()

    def save_friends_to_db(self, friend_id):
        """Saves a new friendship to the database."""
        conn = None
        try:
            conn = sqlite3.connect(db_utils.DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO friends (user_id, friend_id) VALUES (?, ?)", (self.user_id, friend_id))
            conn.commit()
        except sqlite3.IntegrityError:
            print("This friendship already exists.")
        except sqlite3.Error as e:
            print(f"Database error: {e}")
        finally:
            if conn:
                conn.close()

    def update_user_list(self):
        """Updates the user list in the UI."""
        self.user_list.clear()
        for user in self.chat_users:
            self.user_list.addItem(user)

    def select_chat_user(self, item):
        """Selects a chat user and loads the chat."""
        self.current_chat_user = item.text()
        self.chat_area.clear()  # Очищаем chat_area
        self.last_message_time = None  # Сбрасываем last_message_time
        self.load_chat()

    def search_user(self):
        """Searches for a user and adds them to the friend list."""
        username = self.search_input.text()

        if username == self.username:
            QMessageBox.critical(self, "Ошибка", "Нельзя добавить себя в друзья!")
            return

        if not db_utils.download_database():
            QMessageBox.critical(self, "Ошибка", "Не удалось скачать базу данных.")
            return

        conn = None
        try:
            conn = sqlite3.connect(db_utils.DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
            user = cursor.fetchone()

            if user:
                friend_id = user[0]
                if username not in self.friends:
                    self.save_friends_to_db(friend_id)
                    self.friends.append(username)

                self.chat_users.add(username)
                self.update_user_list()

                QMessageBox.information(self, "Успех", f"Пользователь {username} найден и добавлен в друзья!")
                self.current_chat_user = username
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            QMessageBox.critical(self, "Ошибка", f"Произошла ошибка при работе с базой данных: {e}")
        finally:
            if conn:
                conn.close()
            db_utils.upload_database()

    def send_message(self):
        """Sends a message to the selected user."""
        if self.current_chat_user:
            message = self.message_input.text()
            if message:
                if not db_utils.download_database():
                    QMessageBox.critical(self, "Ошибка", "Не удалось скачать базу данных.")
                    return
                self.save_chat_to_db(self.current_chat_user, message)
                self.load_chat() #Обновляем чат сразу после отправки
                self.message_input.clear()

    def save_chat_to_db(self, username, message):
        """Saves the chat message to the database."""
        conn = None
        try:
            conn = sqlite3.connect(db_utils.DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
            user = cursor.fetchone()

            if user:
                receiver_id = user[0]
            else:
                print("Пользователь не найден")
                return

            now = datetime.datetime.now().isoformat()
            cursor.execute("INSERT INTO messages (sender_id, receiver_id, timestamp, message) VALUES (?, ?, ?, ?)",
                           (self.user_id, receiver_id, now, message))
            conn.commit()
            db_utils.upload_database()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            QMessageBox.critical(self, "Ошибка", f"Произошла ошибка при работе с базой данных: {e}")
        finally:
            if conn:
                conn.close()

    def load_chat(self):
        """Loads the chat messages from the database."""
        if not db_utils.download_database():
            print("Не удалось скачать базу данных для загрузки чата.")
            return

        conn = None
        try:
            conn = sqlite3.connect(db_utils.DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (self.current_chat_user,))
            user = cursor.fetchone()

            if user:
                receiver_id = user[0]
            else:
                print("Пользователь не найден")
                return

            sql_query = """
                SELECT
                    messages.sender_id,
                    messages.timestamp,
                    messages.message
                FROM messages
                WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
            """
            params = (self.user_id, receiver_id, receiver_id, self.user_id)

            if self.last_message_time:
                sql_query += " AND timestamp > ?"
                params += (self.last_message_time,)

            sql_query += " ORDER BY timestamp"

            cursor.execute(sql_query, params)
            chat_history = cursor.fetchall()

            messages = []
            for msg in chat_history:
                sender_id, timestamp, message_text = msg
                cursor.execute("SELECT username FROM users WHERE id = ?", (sender_id,))
                sender = cursor.fetchone()
                sender = sender[0] if sender else "Unknown"
                messages.append(f'{sender}: {message_text}')

            # Обновляем chat_area и last_message_time
            self.update_chat_area(messages)
            if messages:
                self.last_message_time = chat_history[-1][1] #Время последнего сообщения

        except sqlite3.Error as e:
            print(f"Database error: {e}")
        finally:
            if conn:
                conn.close()


    def start_polling_timer(self):
        """Запускает таймер для периодической проверки новых сообщений."""
        self.polling_timer = QTimer(self)
        self.polling_timer.timeout.connect(self.check_for_new_messages)
        self.polling_timer.start(self.poll_interval)

    def check_for_new_messages(self):
        """Проверяет наличие новых сообщений и обновляет чат."""
        if self.current_chat_user:
            if not db_utils.download_database():
                print("Не удалось скачать базу данных для проверки новых сообщений.")
                return

            conn = None
            try:
                conn = sqlite3.connect(db_utils.DATABASE_FILE)
                cursor = conn.cursor()
                cursor.execute("SELECT id FROM users WHERE username = ?", (self.current_chat_user,))
                user = cursor.fetchone()
                if user:
                    receiver_id = user[0]
                else:
                    print("Пользователь не найден")
                    return

                sql_query = """
                    SELECT
                        messages.sender_id,
                        messages.timestamp,
                        messages.message
                    FROM messages
                    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
                """
                params = (self.user_id, receiver_id, receiver_id, self.user_id)

                if self.last_message_time:
                    sql_query += " AND timestamp > ?"
                    params += (self.last_message_time,)

                sql_query += " ORDER BY timestamp"

                cursor.execute(sql_query, params)
                new_messages = cursor.fetchall()

                messages = []
                for msg in new_messages:
                    sender_id, timestamp, message_text = msg
                    cursor.execute("SELECT username FROM users WHERE id = ?", (sender_id,))
                    sender = cursor.fetchone()
                    sender = sender[0] if sender else "Unknown"
                    messages.append(f'{sender}: {message_text}')

                self.update_chat_area(messages)
                if new_messages: #Исправлено
                   self.last_message_time = new_messages[-1][1]

            except sqlite3.Error as e:
                print(f"Database error: {e}")
            finally:
                if conn:
                    conn.close()

    def update_chat_area(self, new_messages):
        """Обновляет текстовое поле чата, добавляя новые сообщения."""
        current_text = self.chat_area.toPlainText()
        for message in new_messages:
            current_text += "\n" + message  # Добавляем новые сообщения
        self.chat_area.setText(current_text)

    def start_call(self):
        """Opens a web browser to start a call."""
        import webbrowser
        webbrowser.open("https://calls.vk.com/index.php/")

    def toggle_theme(self):
        """Toggles between dark and light themes."""
        if self.background_color == "#36393F":
            self.background_color = "#FFFFFF"
            self.left_panel_color = "#F0F0F0"
            self.input_background_color = "#E0E0E0"
            self.text_color = "#000000"
        else:
            self.background_color = "#36393F"
            self.left_panel_color = "#2F3136"
            self.input_background_color = "#40444B"
            self.text_color = "#FFFFFF"

        self.setStyleSheet(f"background-color: {self.background_color}; color: {self.text_color};")
        self.left_panel.setStyleSheet(f"background-color: {self.left_panel_color};")
        self.user_list.setStyleSheet(f"""
            QListWidget {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                padding: 5px;
            }}
        """)
        self.chat_area.setStyleSheet(f"""
            QTextEdit {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                padding: 5px;
            }}
        """)
        self.message_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {self.input_background_color};
                color: {self.text_color};
                border: none;
                border-radius: 10px;
                padding: 5px;
            }}
        """)

    def closeEvent(self, event):
        """Handles the closing of the application."""
        self.polling_timer.stop() #Останавливаем таймер
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    if len(sys.argv) > 1:
        username = sys.argv[1]
    else:
        username = "DefaultUser"
    window = GoidaZvonUI(username)
    sys.exit(app.exec_())